import React from 'react'

const ENavBar=
        <nav class="navbar navbar navbar-expand navbar-light">
          <span>Vered Magen & Ron Navon </span>
        </nav>
        
export default ENavBar;
