import React from 'react'

const EHeader=
    
        <div>
           <h1>My Kitchen</h1> 
           <h2>Recipe Dishes</h2> 
        </div>
    
export default EHeader;

