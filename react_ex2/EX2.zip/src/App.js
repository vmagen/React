import './App.css';
import CCMyKitchen from './ClassComponent/CCMyKitchen';

function App() {
  return (
    
    <CCMyKitchen/>
  );
}

export default App;
